public class Exercice2 {
    public static void main(String[] args) {

        int nombreEtudiants = 32;
        double moyenne = 12.75;
        String filiere = "SD-RCC";
        boolean admis = true;SS

        System.out.println(
            nombreEtudiants + " " +
            moyenne + " " +
            filiere + " " +
            admis
        );

        // Étape 2
        // nombreEtudiants = "trente-deux";

        // Étape 3
        System.out.println("7 / 2 = " + (7 / 2));
        System.out.println("7.0 / 2 = " + (7.0 / 2));
        System.out.println("7 % 2 = " + (7 % 2));

        // Étape 4
        int x = 2147483647;
        System.out.println("int max + 1 = " + (x + 1));

        long y = 2147483647L;
        System.out.println("long max + 1 = " + (y + 1));

        // Étape 5
        System.out.println("booléen = " + admis);
    }
}
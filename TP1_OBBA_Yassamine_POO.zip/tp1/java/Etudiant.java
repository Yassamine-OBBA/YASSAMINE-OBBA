import java.util.ArrayList;

public class Etudiant {

    private String cne;
    private String prenom;
    private String nom;
    private ArrayList<Double> notes;

    public Etudiant(Etudiant autre) {
    this.cne = autre.cne;
    this.nom = autre.nom;
    this.prenom = autre.prenom;
    this.notes = new ArrayList<>(autre.notes);
}
public int nombreNotes() {
    return notes.size();
}

    public Etudiant(String cne, String prenom, String nom) {
        this.cne = cne;
        this.prenom = prenom;
        this.nom = nom;
        this.notes = new ArrayList<>();
        


    }

    public void ajouterNote(double note) {

        if (note < 0 || note > 20) {
            throw new IllegalArgumentException(
                "La note doit etre comprise entre 0 et 20."
            );
        }

        notes.add(note);
    }

    public double moyenne() {

        if (notes.isEmpty()) {
            return 0;
        }

        double somme = 0;

        for (double note : notes) {
            somme += note;
        }

        return somme / notes.size();
    }

    public boolean estAdmis() {
        return moyenne() >= 10;
    }

    public void afficher() {

        System.out.println(
            "Etudiant " + cne + " : "
            + prenom + " " + nom
        );

        System.out.println("Notes : " + notes);

        System.out.printf(
            "Moyenne : %.2f%n",
            moyenne()
        );

        System.out.println(
            "Admis : " + estAdmis()
        );
    }

    public ArrayList<Double> getNotes() {
        return notes;
    }
}
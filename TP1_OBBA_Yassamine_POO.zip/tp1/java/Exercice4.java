public class Exercice4 {

    public static void main(String[] args) {

        Etudiant etudiant = new Etudiant(
            "R130456789",
            "Amine",
            "El Idrissi"
        );

        // Ajouter les notes
        etudiant.ajouterNote(12.5);
        etudiant.ajouterNote(9.0);
        etudiant.ajouterNote(14.0);

        // Affichage
        etudiant.afficher();

        // Tester une note incorrecte
        try {
            etudiant.ajouterNote(25);
        }
        catch (IllegalArgumentException e) {
            System.out.println("Erreur : " + e.getMessage());
        }

        // Modification directe de la collection
        etudiant.getNotes().add(18.0);

        System.out.println("\nApres modification directe :");
        etudiant.afficher();
    }
}
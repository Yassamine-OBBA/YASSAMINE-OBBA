import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

class Etudiant {
    String cne;
    String nom;

    Etudiant(String cne, String nom) {
        this.cne = cne;
        this.nom = nom;
    }

    // Étape 3 : égalité fondée sur le CNE
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Etudiant)) return false;

        Etudiant autre = (Etudiant) obj;
        return Objects.equals(this.cne, autre.cne);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cne);
    }
}

public class Exercice6 {
    public static void main(String[] args) {
        // Étape 1 : création des étudiants
        Etudiant a = new Etudiant("R130456789", "AmiDxne sEl Idrissi");
        Etudiant b = a;
        Etudiant c = new Etudiant("R130456789", "Amine El Idrissi");
        Etudiant d = new Etudiant("R135551234", "Amine El Idrissi");

        // Étape 2 : tests d'identité et d'égalité
        System.out.println("a == b : " + (a == b));
        System.out.println("a == c : " + (a == c));
        System.out.println("a == d : " + (a == d));

        System.out.println("a.equals(b) : " + a.equals(b));
        System.out.println("a.equals(c) : " + a.equals(c));
        System.out.println("a.equals(d) : " + a.equals(d));

        Set<Etudiant> ensemble = new HashSet<>();
        ensemble.add(a);
        ensemble.add(b);
        ensemble.add(c);
        ensemble.add(d);

        System.out.println("Taille du HashSet : " + ensemble.size());

        // Étape 4 : comparaison des chaînes
        String s1 = "POO";
        String s2 = new String("POO");

        System.out.println("s1 == s2 : " + (s1 == s2));
        System.out.println("s1.equals(s2) : " + s1.equals(s2));
    }
}
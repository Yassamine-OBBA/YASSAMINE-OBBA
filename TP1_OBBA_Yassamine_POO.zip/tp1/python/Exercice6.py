class Etudiant:
    def __init__(self, cne, nom):
        self.cne = cne
        self.nom = nom

    def __eq__(self, autre):
        if not isinstance(autre, Etudiant):
            return NotImplemented
        return self.cne == autre.cne

    def __hash__(self):
        return hash(self.cne)


# Étape 1 : création des étudiants
a = Etudiant("R130456789", "Amine El Idrissi")
b = a
c = Etudiant("R130456789", "Amine El Idrissi")
d = Etudiant("R135551234", "Amine El Idrissi")

# Étape 2 : tests d'identité et d'égalité
print("a is b :", a is b)
print("a is c :", a is c)
print("a is d :", a is d)

print("a == b :", a == b)
print("a == c :", a == c)
print("a == d :", a == d)

print("Taille du set :", len({a, b, c, d}))

# Étape 4 : comparaison de chaînes
s1 = "POO"
s2 = "".join(["P", "O", "O"])

print("s1 == s2 :", s1 == s2)
print("s1 is s2 :", s1 is s2)
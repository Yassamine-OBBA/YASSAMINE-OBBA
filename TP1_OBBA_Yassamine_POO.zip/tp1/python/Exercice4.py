from Etudiant import Etudiant


# Création de l'étudiant
etudiant = Etudiant(
    "R130456789",
    "Amine",
    "El Idrissi"
)

# Ajouter les notes
etudiant.ajouter_note(12.5)
etudiant.ajouter_note(9.0)
etudiant.ajouter_note(14.0)

# Affichage
etudiant.afficher()

# Tester une note incorrecte
try:
    etudiant.ajouter_note(25)
except ValueError as e:
    print("Erreur :", e)

# Modification directe de la collection
etudiant._notes.append(18.0)

print("\nApres modification directe :")
etudiant.afficher()

class Etudiant:

    def __init__(self, cne, prenom, nom):
        self.cne = cne
        self.prenom = prenom
        self.nom = nom
        self._notes = []

    def ajouter_note(self, note):
        if note < 0 or note > 20:
            raise ValueError(
                "La note doit etre comprise entre 0 et 20."
            )
        self._notes.append(note)

    def nombre_notes(self):
        return len(self._notes)

    def moyenne(self):
        if len(self._notes) == 0:
            return 0
        return sum(self._notes) / len(self._notes)

    def est_admis(self):
        return self.moyenne() >= 10

    def afficher(self):
        print(
            f"Etudiant {self.cne} : "
            f"{self.prenom} {self.nom}"
        )
        print("Notes :", self._notes)
        print(f"Moyenne : {self.moyenne():.2f}")
        print("Admis :", self.est_admis())

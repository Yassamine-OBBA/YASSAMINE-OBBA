def moyenne(notes):
    return sum(notes) / len(notes)


def mention(m):
    if m >= 16:
        return "Tres bien"
    elif m >= 14:
        return "Bien"
    elif m >= 12:
        return "Assez bien"
    elif m >= 10:
        return "Passable"
    else:
        return "Ajourne"


# Liste des notes
notes = [12.5, 9.0, 14.0, 16.5]

# Affichage des notes
print("Notes :")

for i, note in enumerate(notes, start=1):
    print("Note", i, ":", note)

# Calcul de la moyenne
m = moyenne(notes)

print("Moyenne :", f"{m:.2f}")
print("Mention :", mention(m))

# Ajouter une nouvelle note
notes.append(11.0)

print("\nApres ajout de la note 11.0 :")
print("Nombre de notes :", len(notes))
print("Nouvelle moyenne :", f"{moyenne(notes):.2f}")

# Tentative d'accès à la 11e note
try:
    print("11e note :", notes[10])
except IndexError:
    print("Erreur : la 11e note n'existe pas.")
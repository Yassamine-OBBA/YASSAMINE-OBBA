nombre_etudiants = 32
moyenne = 12.75
filiere = "SD-RCC"
admis = True

print(nombre_etudiants, moyenne, filiere, admis)

print(type(nombre_etudiants))
print(type(moyenne))
print(type(filiere))
print(type(admis))

# Étape 2
nombre_etudiants = "trente-deux"
print(nombre_etudiants)

# Étape 3
print("7 / 2 =", 7 / 2)
print("7.0 / 2 =", 7.0 / 2)
print("7 % 2 =", 7 % 2)
print("7 // 2 =", 7 // 2)

# Étape 4
x = 2147483647
print("int max + 1 =", x + 1)
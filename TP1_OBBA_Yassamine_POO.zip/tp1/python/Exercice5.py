import copy
from Etudiant import Etudiant

def bonus(Etudiant):
    Etudiant.ajouter_note(20)


# Étape 1 : affectation
e1 = Etudiant("R130456789", "El Idrissi", "Amine")
e1.ajouter_note(12)

e2 = e1
e2.ajouter_note(15)

print("Étape 1 :")
print("Nombre de notes de e1 :", e1.nombre_notes())
print("Nombre de notes de e2 :", e2.nombre_notes())
print("e1 et e2 sont le même objet :", e1 is e2)

# Étape 2 : copie indépendante
e3 = copy.deepcopy(e1)
e3.ajouter_note(18)

print("\nÉtape 2 :")
print("Nombre de notes de e1 :", e1.nombre_notes())
print("Nombre de notes de e3 :", e3.nombre_notes())
print("e1 et e3 sont le même objet :", e1 is e3)


# Étape 3 : passage en paramètre
bonus(e1)

print("\nÉtape 3 :")
print("Nombre de notes de e1 :", e1.nombre_notes())

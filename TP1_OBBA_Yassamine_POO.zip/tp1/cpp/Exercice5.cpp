#include "Etudiant.h"
#include <iostream>

void modifierEtudiant(Etudiant& e) {
    e.ajouterNote(18.0);
}

int main() {

    Etudiant e1(
        "R130456789", "Amine", "El Idrissi"
    );

    e1.ajouterNote(12.5);
    e1.ajouterNote(14.0);

    // Affectation par référence
    Etudiant& e2 = e1;

    // Copie indépendante
    Etudiant e3 = e1;

    std::cout << "Avant modification :" << std::endl;
    e1.afficher();
    e3.afficher();

    // Modifier l'objet original par e2
    e2.ajouterNote(16.0);

    std::cout << "\nAprès modification de e2 :" << std::endl;
    e1.afficher();
    e3.afficher();

    // Passage par référence
    modifierEtudiant(e1);

    std::cout << "\nAprès passage de e1 à la fonction :" << std::endl;
    e1.afficher();
    e3.afficher();

    return 0;
}
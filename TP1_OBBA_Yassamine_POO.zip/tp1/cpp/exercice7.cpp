#include <iostream>
#include <chrono>

int main() {
    auto debut = std::chrono::steady_clock::now();

    long long somme = 0;
    for (int i = 0; i < 10'000'000; i++) {
        somme += i % 7;
    }

    auto fin = std::chrono::steady_clock::now();

    double duree = std::chrono::duration<double, std::milli>(
        fin - debut
    ).count();

    std::cout << "Somme : " << somme << '\n';
    std::cout << "Duree : " << duree << " ms\n";

    return 0;
}

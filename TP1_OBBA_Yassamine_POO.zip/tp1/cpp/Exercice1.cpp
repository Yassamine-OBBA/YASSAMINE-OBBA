#include <iostream>
using namespace std;

int main() {
    cout << "Bonjour, ESTK !" << endl;
    cout << "Programmation orientee objet en Python." << endl;

    return 0;
}

#include "Etudiant.h"
#include <iostream>
#include <stdexcept>

int main() {

    Etudiant etudiant(
        "R130456789",
        "Amine",
        "El Idrissi"
    );

    // Ajouter les notes
    etudiant.ajouterNote(12.5);
    etudiant.ajouterNote(9.0);
    etudiant.ajouterNote(14.0);

    // Affichage
    etudiant.afficher();

    // Tester une note incorrecte
    try {
        etudiant.ajouterNote(25);
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Erreur : "
                  << e.what()
                  << std::endl;
    }

    // Modification directe de la collection
    etudiant.getNotes().push_back(18.0);

    std::cout << "\nApres modification directe :"
              << std::endl;

    etudiant.afficher();

    return 0;
}
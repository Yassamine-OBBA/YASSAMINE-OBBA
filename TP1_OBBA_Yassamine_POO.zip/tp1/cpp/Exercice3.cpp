#include <iostream>
#include <vector>
#include <stdexcept>
#include <iomanip>

double moyenne(const std::vector<double>& notes) {

    double somme = 0;

    for (double note : notes) {
        somme += note;
    }

    return somme / notes.size();
}

std::string mention(double m) {

    if (m >= 16) {
        return "Tres bien";
    }
    else if (m >= 14) {
        return "Bien";
    }
    else if (m >= 12) {
        return "Assez bien";
    }
    else if (m >= 10) {
        return "Passable";
    }
    else {
        return "Ajourne";
    }
}

int main() {

    std::vector<double> notes = {
        12.5, 9.0, 14.0, 16.5
    };

    std::cout << "Notes :" << std::endl;

    for (size_t i = 0; i < notes.size(); i++) {
        std::cout << "Note " << i + 1
                  << " : " << notes[i] << std::endl;
    }

    double m = moyenne(notes);

    std::cout << std::fixed << std::setprecision(2);

    std::cout << "Moyenne : " << m << std::endl;
    std::cout << "Mention : " << mention(m) << std::endl;

    // Ajouter 11.0
    notes.push_back(11.0);

    std::cout << "\nApres ajout de la note 11.0 :" << std::endl;

    std::cout << "Nombre de notes : "
              << notes.size() << std::endl;

    std::cout << "Nouvelle moyenne : "
              << moyenne(notes) << std::endl;

    // Accès à la 11e note
    try {
        std::cout << "11e note : "
                  << notes.at(10) << std::endl;
    }
    catch (const std::out_of_range& e) {
        std::cout << "Erreur : la 11e note n'existe pas."
                  << std::endl;
    }

    return 0;
}
#include <iostream>
#include <string>

int main() {

    int nombreEtudiants = 32;
    double moyenne = 12.75;
    std::string filiere = "SD-RCC";
    bool admis = true;

    std::cout << nombreEtudiants << " "
              << moyenne << " "
              << filiere << " "
              << admis << std::endl;

    // Étape 2
    // nombreEtudiants = "trente-deux";

    // Étape 3
    std::cout << "7 / 2 = " << 7 / 2 << std::endl;
    std::cout << "7.0 / 2 = " << 7.0 / 2 << std::endl;
    std::cout << "7 % 2 = " << 7 % 2 << std::endl;

    // Étape 4
    int x = 2147483647;
    std::cout << "int max + 1 = " << x + 1 << std::endl;

    long long y = 2147483647LL;
    std::cout << "64 bits + 1 = " << y + 1 << std::endl;

    // Étape 5
    std::cout << "Sans boolalpha : " << admis << std::endl;
    std::cout << std::boolalpha;
    std::cout << "Avec boolalpha : " << admis << std::endl;

    return 0;
}
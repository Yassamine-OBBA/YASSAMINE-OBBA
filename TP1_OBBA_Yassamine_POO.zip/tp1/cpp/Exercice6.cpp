#include <iostream>
#include <string>
using namespace std;

class Etudiant {
public:
    string cne;
    string nom;

    Etudiant(string c, string n) : cne(c), nom(n) {}

    // Étape 3 : égalité fondée sur le CNE
    bool operator==(const Etudiant& autre) const {
        return cne == autre.cne;
    }
};

int main() {
    // Étape 1 : création des étudiants
    Etudiant a("R130456789", "Amine El Idrissi");
    Etudiant& b = a;
    Etudiant c("R130456789", "Amine El Idrissi");
    Etudiant d("R135551234", "Amine El Idrissi");

    // Étape 2 : tests d'identité par adresse
    cout << boolalpha;
    cout << "&a == &b : " << (&a == &b) << endl;
    cout << "&a == &c : " << (&a == &c) << endl;
    cout << "&a == &d : " << (&a == &d) << endl;

    // Étape 3 : tests d'égalité selon le CNE
    cout << "a == b : " << (a == b) << endl;
    cout << "a == c : " << (a == c) << endl;
    cout << "a == d : " << (a == d) << endl;

    // Étape 4 : comparaison de chaînes
    string s1 = "POO";
    string s2("POO");

    cout << "s1 == s2 : " << (s1 == s2) << endl;
}
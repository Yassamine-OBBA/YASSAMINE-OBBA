#include "Etudiant.h"
#include <iostream>
#include <iomanip>
#include <stdexcept>

Etudiant::Etudiant(
    std::string cne,
    std::string prenom,
    std::string nom
)
    : cne(cne),
      prenom(prenom),
      nom(nom) {
}

void Etudiant::ajouterNote(double note) {

    if (note < 0 || note > 20) {
        throw std::invalid_argument(
            "La note doit etre comprise entre 0 et 20."
        );
    }

    notes.push_back(note);
}

double Etudiant::moyenne() const {

    if (notes.empty()) {
        return 0;
    }

    double somme = 0;

    for (double note : notes) {
        somme += note;
    }

    return somme / notes.size();
}

bool Etudiant::estAdmis() const {
    return moyenne() >= 10;
}

void Etudiant::afficher() const {

    std::cout
        << "Etudiant " << cne
        << " : "
        << prenom << " "
        << nom << std::endl;

    std::cout << "Notes : ";

    for (double note : notes) {
        std::cout << note << " ";
    }

    std::cout << std::endl;

    std::cout << std::fixed
              << std::setprecision(2);

    std::cout << "Moyenne : "
              << moyenne()
              << std::endl;

    std::cout << "Admis : "
              << std::boolalpha
              << estAdmis()
              << std::endl;
}

std::vector<double>& Etudiant::getNotes() {
    return notes;
}
#ifndef ETUDIANT_H
#define ETUDIANT_H

#include <string>
#include <vector>

class Etudiant {

private:

    std::string cne;
    std::string prenom;
    std::string nom;
    std::vector<double> notes;

public:

    Etudiant(
        std::string cne,
        std::string prenom,
        std::string nom
    );

    void ajouterNote(double note);

    double moyenne() const;

    bool estAdmis() const;

    void afficher() const;

    std::vector<double>& getNotes();
};

#endif